#!/bin/bash

#Author: Mengyang Wang 

echo "-----problem 1-----"
g++ -o p1 p1.cpp
./p1

echo "-----problem 2-----"
g++ -o p2 p2.cpp
./p2

echo "-----problem 3-----"
g++ -o p3 p3.cpp
./p3

echo "-----problem 4-----"
g++ -o p4 p4.cpp
./p4

rm p1 p2 p3 p4


